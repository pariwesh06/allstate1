Webserver container for the User Signup demo application.

This container is a Tomcat 7 servlet engine with remote debugging enabled.
