Database container for the User Signup demo app

This container is a MySQL 5.6 with the necessary database, tables and passwords set up.
